

<link rel="stylesheet" href="{-filesfoldername-}/ss_wp.css" type="text/css" media="screen" />
<form id=ss method=get action="http://search.yahoo.com/search">
<script type="text/javascript" src="{-filesfoldername-}/ss.js"></script>
<noscript>
<center>
<a href="http://search.yahoo.com/">
<img src="http://us.i1.yimg.com/us.yimg.com/i/ws/w2/search.gif" height="16" width="80" vspace="3" border=0></a><br>
<input type="text" name="p" size=19 style="margin: 3px 0"><br>
<font size="-2"><input type="radio" name="vs" value="" style="vertical-align: middle" checked> Search the web<br>
<input type="radio" name="vs" style="vertical-align: middle" value="mindsack.com"> Search this site</font><br>
<input type="submit" value="Search" style="margin: 3px 0">
</center>
</noscript>
</form>

