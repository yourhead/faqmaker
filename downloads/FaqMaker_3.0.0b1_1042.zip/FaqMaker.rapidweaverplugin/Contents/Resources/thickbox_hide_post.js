
<script type='text/javascript'>
//<![CDATA[



function addLoadEvent(func) {
	var oldonload = window.onload;
		if(typeof window.onload != "function")
				window.onload = func;
		else
				window.onload = function() {
					oldonload();
						func();
				}
}




function showOnlyFaq() {
	
	var bodyIDP = document.getElementsByTagName('body')[0];
	
	
	var faqID=bodyIDP.getElementById('faq');
	
	bodyIDP.setHTML("<div id='container'  ><div id='contentContainer'><div id='content'>"+faqID.innerHTML+"</div><\/div><\/div>");
}

addLoadEvent(showOnlyFaq());
/* 
// Small javascript to hide any misbehaving elemnets

var bodyID = document.getElementsByTagName('body')[0].childNodes;
for (i=0;i<bodyID.length;i++) {
	
	if (bodyID[i].id)
		if (bodyID[i].id!="container") { // 		if (!bodyID[i].getElementsById("container")) { 			bodyID[i].style.display="none";
		} else {
			bodyID[i].style.width='0px';
			bodyID[i].style.minWidth='0px';
			childNodes=bodyID[i].childNodes;
			for (j=0;j<childNodes.length;j++) {
				
				if (childNodes[j].id) {
					//childNodes[j].style.width="auto";
					if (childNodes[j].id!= 'contentContainer')
						childNodes[j].style.display="none";
					else {
						childNodes[j].style.width='100%';
					}
					
				}
				
			}
			bodyID[i].style.width='auto';
		}
}
*/
</script>