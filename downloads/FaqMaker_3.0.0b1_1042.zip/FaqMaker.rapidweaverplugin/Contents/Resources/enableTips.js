
<script type="text/javascript" language="javascript">
window.addEvent('domready', function(){
	var theTips = new TipsX3 ($$('.faq-question'), {
maxTitleChars: 50 //I like my captions a little long
	});
});
</script>